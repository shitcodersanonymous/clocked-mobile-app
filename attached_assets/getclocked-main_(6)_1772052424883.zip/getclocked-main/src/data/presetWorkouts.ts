import { Workout } from '@/types';

// Preset workouts are currently empty — awaiting new workout definitions
export const COMPLETE_BEGINNER_PRESET_WORKOUTS: Workout[] = [];
export const BEGINNER_PRESET_WORKOUTS: Workout[] = [];
export const INTERMEDIATE_PRESET_WORKOUTS: Workout[] = [];
export const ADVANCED_PRESET_WORKOUTS: Workout[] = [];
export const PRO_PRESET_WORKOUTS: Workout[] = [];
export const COACH_PRESET_WORKOUTS: Workout[] = [];
