ALTER TABLE public.profiles ADD COLUMN weight_kg numeric NULL;
ALTER TABLE public.profiles ADD COLUMN height_cm numeric NULL;