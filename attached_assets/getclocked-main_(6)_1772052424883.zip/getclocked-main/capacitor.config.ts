import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.df20c5ba996841dfb2933697cf684445',
  appName: 'getclocked',
  webDir: 'dist',
  server: {
    url: 'https://df20c5ba-9968-41df-b293-3697cf684445.lovableproject.com?forceHideBadge=true',
    cleartext: true
  }
};

export default config;
